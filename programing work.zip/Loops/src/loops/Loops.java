
package loops;


public class Loops {

    public static void main(String[] args) {
        int n = 5;
        int fact = 1;
        int num = 12345, reversed = 0;
        int number = 1234;
        int sum = 0;
        int a = 0 ,b = 1;
        
       // for loop factorial
       for(int i = 1; i <= n; i++){
           fact *= i;
       }
       // fibonacci
       System.out.println("Fibonacci Series: " + a + " " + b);
       for(int i = 2; i < n; i++){
           int c = a + b;
           System.out.println(" " + c);
       a = b;
       b = c;
       }
       // while loop
       while(num != 0){
           int digit = num % 10;
           reversed = reversed * 10 + digit;
               num /= 10;
       }
       // sum
       while(number != 0){
           int digit = number % 10;
            sum += digit;
            number /= 10;
       }
       
       // print
       System.out.println("Factorial of " + n + " = " + fact);
       System.out.println("Reversed Number: " + reversed);
       System.out.println("Sum of digits = " + sum);
       System.out.println("Prim numbers between 1 and 100");
          
        for(int d = 2; d <= 100; n++){
            boolean isPrime = true;
            
            for(int e = 2; e <= d/2; e++){
                if(d % e == 0 ){
                    isPrime = false;
                    break;
                }
            }
            if(isPrime){
                System.out.println( d + " ");
            }
        }
       
       
        
    }
    
}
