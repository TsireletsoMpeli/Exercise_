
package stringjavz;

import java.util.Arrays;
public class StringJavz {

    public static void main(String[] args) {
        String str = "madam";
        String str1 = "listen";
        String str2 = "silent";
        String reversed = "";
        String chr= "Hello World";
        String sentence = "Java programming is interesting ";
        String[] words = sentence.split("");
        String longest = "";
        int count = 0;
        String bhr = "programming";
        int[] freq = new int[256];
        chr = chr.toLowerCase();
        
        
        //palindrome
        for(int i = str.length() - 1; i >= 0; i--){
            reversed += str.charAt(i);
        }
        if(str.equals(reversed)){
            System.out.println(str + " id a palindrome.");
        }else{
            System.out.println( str + " is not a palindrome.");
        }
         
        // vowels
        for(int i = 0; i < chr.length(); i++){
            char ch = chr.charAt(i);
             if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'){
                 count++;
             }
        }
        System.out.println("Number of vowels: " + count);
        
        //character
        
        for(int i = 0; i < bhr.length(); i++){
            freq[bhr.charAt(i)]++;
        }
        System.out.println("Character frequencies: ");
           for(int i = 0; i < freq.length; i++){
               if(freq[i] != 0){
                   System.out.println((char) i + " = "+ freq[i]);
               }
           }
           // angrams 
           char[] arr1 = str1.toCharArray();
           char[] arr2 = str2.toCharArray();
             
           Arrays.sort(arr1);
           Arrays.sort(arr2);
           
           if(Arrays.equals(arr1,arr2)){
               System.out.println("The string are anagrams.");
           }else{
               System.out.println("The string are not anagrams.");
           }
           // String
           for(String word : words){
               if(word.length() > longest.length()){
                   longest = word;
               }
           }
         System.out.println("Longest word: " + longest);
         
           
    }
    
}
