
package bankacc;


public class BankAcc {
    String accountHolder;
    double balance;

    BankAcc(String name, double initialBalance) {
        accountHolder = name;
        balance = initialBalance;
    }

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount + ", Balance: " + balance);
    }

    void withdraw(double amount) {
        if(amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount + ", Balance: " + balance);
        } else {
            System.out.println("Insufficient balance!");
        }
    }

   
    public static void main(String[] args) {
           BankAcc acc = new BankAcc("Alice", 1000);
        acc.deposit(500);
        acc.withdraw(300);
        acc.withdraw(1500);
}
    }
    

