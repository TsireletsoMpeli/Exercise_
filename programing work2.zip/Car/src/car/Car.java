
package car;


public class Car {

String brand;
    String  model;
    int year;
    
    void displayInfo(){
        System.out.println("Brand: " + brand + " ,Model " + ", Year " + year);
    }
    
       
    public static void main(String[] args) {
      Car c1= new Car();
        c1.brand = " Honda";
        c1.model = " fit ";
        c1.year = 2023;
        c1.displayInfo();
    }
    
}
