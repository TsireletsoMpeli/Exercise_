
package methhodjav;

import static methhodjav.MethhodJav.FactorialMethod.factorial;
import static methhodjav.MethhodJav.GCD.gcd;


public class MethhodJav {
     static boolean isPrime(int n ) {
  
        if(n <= 1) return false;
         for(int i = 2; i <= n /2; i++){
             if(n % i == 0 )return false;
         }
         return true;  
    }
public class FactorialMethod{
        static int factorial(int n){
            int fact = 1;
            
            
            for(int i = 1; i <= n; i++){
                fact *= i;
            }
            return fact;
        }
}
public class GCD{
    static int gcd(int a, int b){
        while (b != 0){
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
   
     public static void main(String[] args){
         int num = 5;
         int x = 56;
         int y = 98;
         System.out.println("Factorial of " + num + " = " + factorial(num));
         System.out.println(num + " is prime? " + isPrime(num));
         System.out.println("GCD of " + x + " and " + y +" = " + gcd(x,y));
     }
     
    
}
