
package studentinfo;


public class StudentInfo {
      String name;
    int age;

    // Constructor 1
    StudentInfo(String n, int a) {
        name = n;
        age = a;
    }

    // Constructor 2 (Overloaded)
    StudentInfo(String n) {
        name = n;
        age = 18; // default age
    }

    void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }

    
    public static void main(String[] args) {
         StudentInfo s1 = new StudentInfo("Bob", 20);
        StudentInfo s2 = new StudentInfo("Alice");
        s1.display();
        s2.display();

        
    }
    
}
